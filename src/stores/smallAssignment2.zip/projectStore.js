import { defineStore } from 'pinia';

export const useProjectStore = defineStore('project', {
  state: () => ({
    projects: ["Vue Portfolio", "AI Stock Predictor", "Heart Disease Classifier"],
  }),
  actions: {
    addProject(projectName) {
      this.projects.push(projectName);
    },
    clearProjects() {
      this.projects = [];
    }
  },
  persist: true
});
